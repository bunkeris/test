# Antimatter Dimensions Challenging

In this mod, some Eternity Challenge can be completed more than 5 times.  
EC9,EC10,EC11,EC12 are harder. EC12 reward is nerfed. TS232 is nerfed.  
Prize of time studies 19x,20x,21x,22x,23x are increased.  
If EC2,EC4 or EC9 is completed more than 5 times, then the reward cap is increased.

This mod is balanced until e7800 EP.